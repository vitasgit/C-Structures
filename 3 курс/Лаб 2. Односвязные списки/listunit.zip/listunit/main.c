#include <stdio.h>
#include "listunit_l1.h"

int main()
{
    //tnodeL1 *phead = NULL;
    pnodeL1 phead = NULL, n1, n2, n3;
    phead = createNodeL1("1");
    // n1 = createNodeL1("2");
    // n2 = createNodeL1("3");
    // n3 = createNodeL1("4");
    // addLastNodeL1(&phead, n1);
    // addLastNodeL1(&phead, n2);
    // addLastNodeL1(&phead, n3);
    //disposeListL1(&phead);
    //listOutL1(phead);
    // addLastNodeL1(&phead, createNodeL1("4"));
    // addLastNodeL1(&phead, createNodeL1("5"));
    // addLastNodeL1(&phead, createNodeL1("6"));
    listOutL1(phead);
    printf("----\n");

    //n1->pnext = n2;
    // printf("%p\n", n1);
    // disposeNodeL1(&n1);
    // printf("%p\n", n1);

    // n1 = addLastNodeL1(&phead, createNodeL1("2"));
    // n2 = addLastNodeL1(&phead, createNodeL1("3"));
    // n3 = addLastNodeL1(&phead, createNodeL1("4"));
    // listOutL1(phead);
    // printf("----\n");
    // deleteAfterNodeL1(n1);
    // //disposeAfterNodeL1(n1);
    // listOutL1(phead);


    // addLastNodeL1(&phead,n1);
    // addLastNodeL1(&phead,n2);
    // listOutL1(phead);
    // printf("----\n");
    // disposeListL1(&phead);
    // listOutL1(phead);

    // addLastNodeL1(&phead,n1);
    // addLastNodeL1(&phead,n2);
    // addLastNodeL1(&phead,createNodeL1("10"));
    // addLastNodeL1(&phead,createNodeL1("11"));
    // listOutL1(phead);
    // printf("c = %d\n", listCountL1(phead));
    
    // printf("----\n");
    // deleteAfterNodeL1(n1);
    // listOutL1(phead);
    // printf("c = %d\n", listCountL1(phead));


    // char s[100] = {'\0'};
    // char *d = "--";
    // char *res = NULL;
    // listOutL1(phead);
    // res = listSumStr(s, sizeof(s), phead, d);
    // printf("res: %s\n", res);

    // listOutL1(phead);
    // listActionL1(phead, sum);
    // printf("sum = %d\n", sumvar);
    


    

    
    
    // если передаем голову = nil
    // listOutL1(phead);
    // insertAfterNodeL1(phead, createNodeL1("7"));
    // listOutL1(phead);
    // printf("%s\n", phead->data);

    // phead = createNodeL1("1");
    // listOutL1(phead);
    // insertAfterNodeL1(phead, createNodeL1("7"));
    // listOutL1(phead);







    // listOutL1(phead);
    // printf("----\n");
    // addFirstNodeL1(&phead, createNodeL1("2"));
    // listOutL1(phead);
    // printf("----\n");
    // addFirstNodeL1(&phead, createNodeL1("3"));
    // listOutL1(phead);

    // printf("----\n");
    // addLastNodeL1(&phead, createNodeL1("4"));
    // listOutL1(phead);

    // printf("----\n");
    // //printf("%s\n", phead->data);
    // insertAfterNodeL1(phead->pnext->pnext, createNodeL1("7"));
    // listOutL1(phead);



    // tnodeL1 a = {"1"}, b={"2"}, c={"3"}, t = {"10"};
    // phead = &a;
    // a.pnext = &b;
    // b.pnext = &c;
    // c.pnext = NULL;
    // printf("%s\n", a.data);  // выводит 1


    // tnodeL1 *p = phead;
    // printf("%s\n", p->data);  // выводит 1 (*p).data
    //phead = createNodeL1("1");  // присваивается указатель на узел, где есть значение "1"


    return 0;
}
