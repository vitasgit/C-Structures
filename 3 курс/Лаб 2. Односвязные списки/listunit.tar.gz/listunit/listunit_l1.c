#include "listunit_l1.h"
#include <stdio.h>

 pnodeL1 createNodeL1(char *data)
 {
  return NULL;
 }

 pnodeL1 addFirstNodeL1(pnodeL1 *ph, pnodeL1 p)
 {
  return NULL;
 }

 pnodeL1 addLastNodeL1(pnodeL1 *ph, pnodeL1 p)
 {
  return NULL;
 }

 pnodeL1 insertAfterNodeL1(pnodeL1 pn, pnodeL1 p)
 {
  return NULL;
 }

 void disposeNodeL1(pnodeL1 *pn)
 {}

 pnodeL1 deleteAfterNodeL1(pnodeL1 pn)
 {
  return NULL;
 }

 void disposeAfterNodeL1(pnodeL1 pn)
 {}

 void disposeListL1(pnodeL1 *ph)
 {}

 void listActionL1(pnodeL1 ph, listfunc func)
 {}

 void listOutL1(pnodeL1 ph)
 {}

 int listCountL1(pnodeL1 ph) 
 {}

 char *listSumStr(char *dest, int maxsize, pnodeL1 ph, char *delimiter)
 {
  return NULL;
 }